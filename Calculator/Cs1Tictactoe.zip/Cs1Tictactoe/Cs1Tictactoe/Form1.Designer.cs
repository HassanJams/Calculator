﻿using System.Drawing;
using System.Windows.Forms;


namespace Cs1Tictactoe
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.bt9 = new System.Windows.Forms.Button();
            this.bt8 = new System.Windows.Forms.Button();
            this.bt7 = new System.Windows.Forms.Button();
            this.bt6 = new System.Windows.Forms.Button();
            this.bt5 = new System.Windows.Forms.Button();
            this.bt4 = new System.Windows.Forms.Button();
            this.bt3 = new System.Windows.Forms.Button();
            this.bt2 = new System.Windows.Forms.Button();
            this.bt1 = new System.Windows.Forms.Button();
            this.newBtn = new System.Windows.Forms.Button();
            this.exitBtn = new System.Windows.Forms.Button();
            this.finalMessage = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.bt9);
            this.panel1.Controls.Add(this.bt8);
            this.panel1.Controls.Add(this.bt7);
            this.panel1.Controls.Add(this.bt6);
            this.panel1.Controls.Add(this.bt5);
            this.panel1.Controls.Add(this.bt4);
            this.panel1.Controls.Add(this.bt3);
            this.panel1.Controls.Add(this.bt2);
            this.panel1.Controls.Add(this.bt1);
            this.panel1.Location = new System.Drawing.Point(3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(600, 604);
            this.panel1.TabIndex = 0;
            // 
            // bt9
            // 
            this.bt9.Font = new System.Drawing.Font("Segoe Fluent Icons", 18F, System.Drawing.FontStyle.Bold);
            this.bt9.Location = new System.Drawing.Point(400, 400);
            this.bt9.Name = "bt9";
            this.bt9.Size = new System.Drawing.Size(200, 200);
            this.bt9.TabIndex = 15;
            this.bt9.Text = "button9";
            this.bt9.UseVisualStyleBackColor = true;
            this.bt9.Click += new System.EventHandler(this.numButton_Click);
            // 
            // bt8
            // 
            this.bt8.Font = new System.Drawing.Font("Segoe Fluent Icons", 18F, System.Drawing.FontStyle.Bold);
            this.bt8.Location = new System.Drawing.Point(200, 400);
            this.bt8.Name = "bt8";
            this.bt8.Size = new System.Drawing.Size(200, 200);
            this.bt8.TabIndex = 14;
            this.bt8.Text = "button8";
            this.bt8.UseVisualStyleBackColor = true;
            this.bt8.Click += new System.EventHandler(this.numButton_Click);
            // 
            // bt7
            // 
            this.bt7.Font = new System.Drawing.Font("Segoe Fluent Icons", 18F, System.Drawing.FontStyle.Bold);
            this.bt7.Location = new System.Drawing.Point(0, 400);
            this.bt7.Name = "bt7";
            this.bt7.Size = new System.Drawing.Size(200, 200);
            this.bt7.TabIndex = 13;
            this.bt7.Text = "button7";
            this.bt7.UseVisualStyleBackColor = true;
            this.bt7.Click += new System.EventHandler(this.numButton_Click);
            // 
            // bt6
            // 
            this.bt6.Font = new System.Drawing.Font("Segoe Fluent Icons", 18F, System.Drawing.FontStyle.Bold);
            this.bt6.Location = new System.Drawing.Point(400, 200);
            this.bt6.Name = "bt6";
            this.bt6.Size = new System.Drawing.Size(200, 200);
            this.bt6.TabIndex = 12;
            this.bt6.Text = "button6";
            this.bt6.UseVisualStyleBackColor = true;
            // 
            // bt5
            // 
            this.bt5.Font = new System.Drawing.Font("Segoe Fluent Icons", 18F, System.Drawing.FontStyle.Bold);
            this.bt5.Location = new System.Drawing.Point(200, 200);
            this.bt5.Name = "bt5";
            this.bt5.Size = new System.Drawing.Size(200, 200);
            this.bt5.TabIndex = 11;
            this.bt5.Text = "button5";
            this.bt5.UseVisualStyleBackColor = true;
            this.bt5.Click += new System.EventHandler(this.numButton_Click);
            // 
            // bt4
            // 
            this.bt4.Font = new System.Drawing.Font("Segoe Fluent Icons", 18F, System.Drawing.FontStyle.Bold);
            this.bt4.Location = new System.Drawing.Point(0, 200);
            this.bt4.Name = "bt4";
            this.bt4.Size = new System.Drawing.Size(200, 200);
            this.bt4.TabIndex = 10;
            this.bt4.Text = "button4";
            this.bt4.UseVisualStyleBackColor = true;
            this.bt4.Click += new System.EventHandler(this.numButton_Click);
            // 
            // bt3
            // 
            this.bt3.Font = new System.Drawing.Font("Segoe Fluent Icons", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt3.Location = new System.Drawing.Point(400, 0);
            this.bt3.Name = "bt3";
            this.bt3.Size = new System.Drawing.Size(200, 200);
            this.bt3.TabIndex = 9;
            this.bt3.Text = "button3";
            this.bt3.UseVisualStyleBackColor = true;
            this.bt3.Click += new System.EventHandler(this.numButton_Click);
            // 
            // bt2
            // 
            this.bt2.Font = new System.Drawing.Font("Segoe Fluent Icons", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt2.Location = new System.Drawing.Point(200, 0);
            this.bt2.Name = "bt2";
            this.bt2.Size = new System.Drawing.Size(200, 200);
            this.bt2.TabIndex = 2;
            this.bt2.Text = "button2";
            this.bt2.UseVisualStyleBackColor = true;
            this.bt2.Click += new System.EventHandler(this.numButton_Click);
            // 
            // bt1
            // 
            this.bt1.Font = new System.Drawing.Font("Segoe Fluent Icons", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt1.Location = new System.Drawing.Point(1, 0);
            this.bt1.Name = "bt1";
            this.bt1.Size = new System.Drawing.Size(200, 200);
            this.bt1.TabIndex = 0;
            this.bt1.Text = "button1";
            this.bt1.UseVisualStyleBackColor = true;
            this.bt1.Click += new System.EventHandler(this.numButton_Click);
            // 
            // newBtn
            // 
            this.newBtn.Location = new System.Drawing.Point(45, 612);
            this.newBtn.Name = "newBtn";
            this.newBtn.Size = new System.Drawing.Size(196, 50);
            this.newBtn.TabIndex = 2;
            this.newBtn.Text = "Start New Game ";
            this.newBtn.UseVisualStyleBackColor = true;
            this.newBtn.Click += new System.EventHandler(this.newBtn_Click);
            // 
            // exitBtn
            // 
            this.exitBtn.Location = new System.Drawing.Point(328, 612);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(196, 50);
            this.exitBtn.TabIndex = 3;
            this.exitBtn.Text = "Exit";
            this.exitBtn.UseVisualStyleBackColor = true;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click);
            // 
            // finalMessage
            // 
            this.finalMessage.Location = new System.Drawing.Point(54, 668);
            this.finalMessage.Name = "finalMessage";
            this.finalMessage.Size = new System.Drawing.Size(456, 50);
            this.finalMessage.TabIndex = 4;
            this.finalMessage.UseVisualStyleBackColor = true;
            this.finalMessage.Click += new System.EventHandler(this.finalMessage_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(608, 723);
            this.Controls.Add(this.finalMessage);
            this.Controls.Add(this.exitBtn);
            this.Controls.Add(this.newBtn);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "TINFO-200 Cs1-Tic-Tac-Toe";
            this.Load += new System.EventHandler(this.newBtn_Click);
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button bt9;
        private System.Windows.Forms.Button bt8;
        private System.Windows.Forms.Button bt7;
        private System.Windows.Forms.Button bt6;
        private System.Windows.Forms.Button bt5;
        private System.Windows.Forms.Button bt4;
        private System.Windows.Forms.Button bt3;
        private System.Windows.Forms.Button bt2;
        private System.Windows.Forms.Button bt1;
        private System.Windows.Forms.Button newBtn;
        private System.Windows.Forms.Button exitBtn;
        private Button finalMessage;
    }
}

