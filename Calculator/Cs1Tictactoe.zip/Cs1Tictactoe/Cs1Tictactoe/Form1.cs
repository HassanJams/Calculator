﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Cs1Tictactoe
{
    public partial class Form1 : Form
    {
        private bool turn; // true = X (Human), false = O (Computer)
        private int turnCount = 0;
        private bool gameFinished = false;
        private Random random = new Random();
        private List<Button> buttons = new List<Button>();

        public Form1()
        {
            InitializeComponent();
            InitializeGame();
        }

        private void InitializeGame()
        {
            buttons = new List<Button> { bt1, bt2, bt3, bt4, bt5, bt6, bt7, bt8, bt9 };

            foreach (Button button in buttons)
            {
                button.Text = ""; // Reset text
                button.Enabled = true; // Re-enable buttons
                button.BackColor = SystemColors.Control; // Reset background color
            }

            turn = random.Next(2) == 0; // Randomly choose who starts
            turnCount = 0;
            gameFinished = false;

            if (!turn)
                ComputerMove(); // If computer is chosen to start, it plays first
        }

        private void numButton_Click(object sender, EventArgs e)
        {
            if (gameFinished) return;

            Button b = (Button)sender;
            b.Text = "X";
            b.Enabled = false;
            turnCount++;

            if (CheckWinner("X"))
            {
                gameFinished = true;
                HighlightWinningButtons("X");
                finalMessage.Text = "YOU WON!!!!";

                DisableAllButtons();
                return;
            }

            if (turnCount >= 9)
            {
                gameFinished = true;
                finalMessage.Text = " CATS GAME!";
                DisableAllButtons(); // Tie
                return;
            }

            turn = false;
            ComputerMove();
        }

        private void ComputerMove()
        {
            if (gameFinished) return;

            List<Button> availableButtons = buttons.Where(b => b.Text == "").ToList();
            if (availableButtons.Count == 0) return;

            Button move = availableButtons[random.Next(availableButtons.Count)];
            move.Text = "O";
            move.Enabled = false;
            turnCount++;

            if (CheckWinner("O"))
            {
                gameFinished = true;
                finalMessage.Text = "Computer WON!!!!";
                HighlightWinningButtons("0");
                DisableAllButtons();
            }
            else if (turnCount >= 9)
            {
                gameFinished = true;
                finalMessage.Text = "CATS GAME!";
                DisableAllButtons(); // Tie
            }
            else
            {
                turn = true;
            }
        }

        private bool CheckWinner(string mark)
        {
            // Winning combinations (indexed to `buttons` list)
            int[,] winningCombinations = {
            {0, 1, 2}, {3, 4, 5}, {6, 7, 8}, // Rows
            {0, 3, 6}, {1, 4, 7}, {2, 5, 8}, // Columns
            {0, 4, 8}, {2, 4, 6}             // Diagonals
        };

            // Iterate over all winning combinations
            for (int i = 0; i < winningCombinations.GetLength(0); i++)
            {
                int a = winningCombinations[i, 0];
                int b = winningCombinations[i, 1];
                int c = winningCombinations[i, 2];

                if (buttons[a].Text == mark &&
                    buttons[b].Text == mark &&
                    buttons[c].Text == mark)
                {
                    gameFinished = true;
                    return true;
                }
            }

            return false;
        }


        private void HighlightWinningButtons(string winner)
        {
            int[,] winningCombinations = {
             {0, 1, 2}, {3, 4, 5}, {6, 7, 8}, // Rows
             {0, 3, 6}, {1, 4, 7}, {2, 5, 8}, // Columns
             {0, 4, 8}, {2, 4, 6}             // Diagonals
             };

            // Find the winning combination
            for (int i = 0; i < winningCombinations.GetLength(0); i++)
            {
                int a = winningCombinations[i, 0];
                int b = winningCombinations[i, 1];
                int c = winningCombinations[i, 2];

                if (buttons[a].Text == winner &&
                    buttons[b].Text == winner &&
                    buttons[c].Text == winner)
                {
                    //  Turn winning buttons GREEN
                    buttons[a].BackColor = Color.LightGreen;
                    buttons[b].BackColor = Color.LightGreen;
                    buttons[c].BackColor = Color.LightGreen;

                    // Turn all losing buttons RED
                    foreach (Button btn in buttons)
                    {
                        if (btn.Text != "" && btn.BackColor != Color.LightGreen)
                        {
                            btn.BackColor = Color.Red;
                        }
                    }

                    break;
                }
            }
        }

        private void DisableAllButtons()
        {
            foreach (Button btn in buttons)
            {
                btn.Enabled = false;
            }
        }

        private void newBtn_Click(object sender, EventArgs e)
        {
            InitializeGame();
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // Assign button clicks to the same method
        private void bt1_Click(object sender, EventArgs e) => numButton_Click(sender, e);
        private void bt2_Click(object sender, EventArgs e) => numButton_Click(sender, e);
        private void bt3_Click(object sender, EventArgs e) => numButton_Click(sender, e);
        private void bt4_Click(object sender, EventArgs e) => numButton_Click(sender, e);
        private void bt5_Click(object sender, EventArgs e) => numButton_Click(sender, e);
        private void bt6_Click(object sender, EventArgs e) => numButton_Click(sender, e);
        private void bt7_Click(object sender, EventArgs e) => numButton_Click(sender, e);
        private void bt8_Click(object sender, EventArgs e) => numButton_Click(sender, e);
        private void bt9_Click(object sender, EventArgs e) => numButton_Click(sender, e);

        private void finalMessage_Click(object sender, EventArgs e)
        {
            
            // Do nothing because finalMessage is just for displaying the result
        }
    }
}
